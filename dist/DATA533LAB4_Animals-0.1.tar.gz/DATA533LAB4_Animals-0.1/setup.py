from setuptools import setup, find_packages

setup(
    name='DATA533LAB4_Animals',
    version='0.1',
    packages=find_packages(exclude=['*test*']),
    license='MIT',
    description='DATA533_lab4',
    url='https://github.com/Astarter/DATA533_Lab4',
    author='Bohan Gao and Vicens Paneque',
    author_email='gbh958810784@gmail.com'
)